<?php
/*
 * bedita.cfg.php - local installation specific settings,
 *                 overrides settings in bedita.ini
 * 
 */

$config["projectName"] = "BE demo";

/**
 ** ******************************************
 **  Content and UI Elements defaults
 ** ******************************************
 */

// User Interface default language [see also 'multilang' below]
//$config['Config']['language'] = "ita"; // or "eng", "spa", "por"

// Set 'multilang' true for user choice [also set 'multilang' true if $config['Config']['language'] is set]
// $config['multilang'] = true;
// $config['defaultLang'] = "ita"; // default fallback


// Texts in documents ['html', 'txt', 'txtParsed']
// $config['type'] = "txt" ;  // ------ SISTEMARE IL NOME FA CA'  ------------
//$config['defaultTxtType'] = "txt" ;


// Status of new objects
// $config['status'] = "draft" ;  // ------ SISTEMARE IL NOME FA CA' ------------
//$config['defaultStatus'] = "draft" ;


// TinyMCE Rich Text Editor for long_text ['false' to disable - defaults true]
// $config['mce'] = true;


// Upload mode ['flash', 'ajax']
// $config['uploadType'] = "flash";



// download - redirect extensions to mediaURL [FrontenController::download]
$config["redirectExtensionsDownload"] = array ("gz", "tar", "zip");


/**
 ** ******************************************
 **  Local installation specific settings
 ** ******************************************
 */

// $config["objRelationType"] = array ("language", "parent");

// One-way relation
// $config["cfgOneWayRelation"] = array("parent");

// Reserved words [avoided in nickname creation]
// $config["cfgReservedWords"] = array();


// $config['searchFields'] = array(
//	'ModelName' => array('title'=> 6, 'description' => 4),
//) ;


// specific css filename for newsletter templates
//$config['newsletterCss'] = "base.css";


$config['langOptions'] = array(
 "eng"=>"English",
 "ita"=>"Italiano",
 );

?>
