<?php
/*-----8<--------------------------------------------------------------------
 * 
 * BEdita - a semantic content management framework
 * 
 * Copyright 2008 ChannelWeb Srl, Chialab Srl
 * 
 * This file is part of BEdita: you can redistribute it and/or modify
 * it under the terms of the Affero GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, or 
 * (at your option) any later version.
 * BEdita is distributed WITHOUT ANY WARRANTY; without even the implied 
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the Affero GNU General Public License for more details.
 * You should have received a copy of the Affero GNU General Public License 
 * version 3 along with BEdita (see LICENSE.AGPL).
 * If not, see <http://gnu.org/licenses/agpl-3.0.html>.
 * 
 *------------------------------------------------------------------->8-----
 */


// BEdita instance name 
$config["projectName"] =  "Test[Bed]ita";

/**
 ** ******************************************
 **  FileSystem Paths, URIs, Files defaults
 ** ******************************************
 */
// BEdita URL
$config['beditaUrl'] = "http://test.bedita.com";

/** Multimedia - files root folder on filesystem (use absolute path, if you need to change it)
 **
 **	On Linux could be /var/www/bedita/bedita-app/webroot/files
 ** On Windows could be C:\\xampp\\htdocs\\bedita\\bedita-app\\webroot\\files
 ** Or you can use DS as crossplatform directory separator as in default
 ** APP_PATH . "webroot" . DS . "files"
 ** where APP_PATH constant points to bedita/bedita_app/ dir
 */
$config['mediaRoot'] = BEDITA_CORE_PATH . DS . "webroot" . DS . "files";

// Multimedia - URL prefix (without trailing slash)
$config['mediaUrl'] = $config['beditaUrl'] . '/files';

// alternative frontends path (absolute path)
//define('BEDITA_FRONTENDS_PATH', '/var/www/bedita/bedita-frontends');

// alternative bedita modules path (absolute path)
//define('BEDITA_MODULES_PATH', '/var/www/bedita/bedita-plugins');

// alternative bedita addons path (absolute path)
//define('BEDITA_ADDONS_PATH', '/var/www/bedita/bedita-addons');

/**
 ** ******************************************
 **  Statistics settings
 ** ******************************************
 */
 
// apache log statistics url - e.g. awstats ...
//$config["logStatsUrl"] = array(
//	"pub-nickname" => "http://user:passwd@awstatsurl",
//);


/**
 ** ******************************************
 **  SMTP and mail support settings
 ** ******************************************
 */
 
/** 
 ** smtp server configuration used for any kind of mail (notifications, newsletters, etc...)
 */
//$config['smtpOptions'] = array(
//	'port' => '25',
//	'timeout' => '30',
//	'host' => 'your.smtp.server',
//	'username' => 'your_smtp_username',
//	'password' => 'your_smtp_password'
//);

/**
 * mail support configuration
 * uncomment and fill to send error messages to your support
 */
//$config["mailSupport"] = array(
//	"from" => "bedita-support@...",	
//	'to' => "bedita-support@...",
//	'subject' => "[bedita] error message",
//);

/**
 ** ******************************************
 **  Content and UI Elements defaults
 ** ******************************************
 */

// User Interface default language [see also 'multilang' below]
//$config['Config']['language'] = "ita"; // or "eng", "spa", "por"

// Set 'multilang' true for user choice [also set 'multilang' true if $config['Config']['language'] is set]
// $config['multilang'] = true;
// $config['defaultLang'] = "eng"; // default fallback

// Status of new objects
//$config['defaultStatus'] = "draft" ;

// TinyMCE Rich Text Editor for long_text ['false' to disable - defaults true]
// $config['mce'] = true;


/**
 ** ******************************************
 **  Login (backend) and Security Policies
 ** ******************************************
 */
//
// A simple example with a simple password regexp rule, uncomment and change according to your needs
//
//$config['loginPolicy'] = array (
//	"maxLoginAttempts" => 3,
//	"maxNumDaysInactivity" => 60,
//	"maxNumDaysValidity" => 10,
//	"passwordRule" => "/\w{4,}/", // regexp to match for valid passwords (empty => no regexp)
//	"passwordErrorMessage" => "Password must contain at least 4 valid alphanumeric characters", // error message for passwrds not matching given regexp
//);



/**
 ** ******************************************
 **  Local installation specific settings
 ** ******************************************
 */

 
/**
 ** Relations - local objects' relation types
 ** define here custom semantic relations
 */
// $config["objRelationType"] = array(
// 		"language" => array()
// );

// One-way relation, array of objRelationType keys
// $config["cfgOneWayRelation"] = array();

// Reserved words [avoided in nickname creation]
// $config["cfgReservedWords"] = array();

/**
 * Lang selection options ISO-639-3 - Language options for contents
 */
//$config['langOptions'] = array(
//	"ita"	=> "italiano",
//	"eng"	=> "english",
//	"spa"	=> "espa&ntilde;ol",
//	"por"	=> "portugu&ecirc;s",
//	"fra"	=> "fran&ccedil;ais",
//	"deu"	=> "deutsch"
//) ;


// add langs.iso.php to language options for content 
//$config['langOptionsIso'] = false; 


// default values for fulltext search
// $config['searchFields'] = array(
//	'ModelName' => array('title'=> 6, 'description' => 4),
//) ;


// specific css filename for newsletter templates
//$config['newsletterCss'] = "base.css";

/**
 * save history navigation
 
 * "sessionEntry" => number of history items in session
 * "showDuplicates" => false to not show duplicates in history session 
 * "trackNotLogged" => true save history for all users (not logged too)
 */
//$config["history"] = array(
//	"sessionEntry" => 5,
//	"showDuplicates" => false,
//	"trackNotLogged" => false
//);

?>
