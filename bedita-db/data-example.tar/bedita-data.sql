SET FOREIGN_KEY_CHECKS=0;
INSERT INTO annotations (`id`,`object_id`) VALUES ('16','13');
INSERT INTO annotations (`id`,`object_id`) VALUES ('17','13');
INSERT INTO annotations (`id`,`object_id`,`author`,`email`) VALUES ('20','19','Andy','andy@pipkin.com');
INSERT INTO annotations (`id`,`object_id`,`author`,`email`) VALUES ('21','19','Carol','carl@beer.com');
INSERT INTO areas (`id`,`public_name`,`public_url`,`staging_url`,`email`) VALUES ('1','my tv movies','','','ste@channelweb.it');
INSERT INTO categories (`id`,`label`,`name`,`object_type_id`,`status`) VALUES ('1','Image','image','12','on');
INSERT INTO categories (`id`,`label`,`name`,`status`) VALUES ('2','sci-fi','sci-fi','on');
INSERT INTO categories (`id`,`label`,`name`,`object_type_id`,`status`) VALUES ('3','Video','video','32','on');
INSERT INTO categories (`id`,`label`,`name`,`status`) VALUES ('4','british','british','on');
INSERT INTO categories (`id`,`label`,`name`,`status`) VALUES ('5','sketches','sketches','on');
INSERT INTO categories (`id`,`label`,`name`,`status`) VALUES ('6','BBC','bbc','on');
INSERT INTO categories (`id`,`label`,`name`,`status`) VALUES ('7','Matt Lucas','matt lucas','on');
INSERT INTO categories (`id`,`label`,`name`,`status`) VALUES ('8','David Walliams','david walliams','on');
INSERT INTO contents (`id`,`abstract`,`body`,`type`) VALUES ('3','','<p><em><strong>I Soprano</strong></em> &egrave; una <a title=\"Serie televisiva\" href=\"http://it.wikipedia.org/wiki/Serie_televisiva\">serie televisiva</a> prodotta dall\'<a title=\"Emittente televisiva\" href=\"http://it.wikipedia.org/wiki/Emittente_televisiva\">emittente</a> americana <a class=\"mw-redirect\" title=\"HBO\" href=\"http://it.wikipedia.org/wiki/HBO\">HBO</a> e trasmessa in <a title=\"Italia\" href=\"http://it.wikipedia.org/wiki/Italia\">Italia</a> per la prima volta dalla rete televisiva <a title=\"Canale 5\" href=\"http://it.wikipedia.org/wiki/Canale_5\">Canale 5</a>. Ideatore e produttore della serie &egrave; lo <a class=\"mw-redirect\" title=\"Sceneggiatore\" href=\"http://it.wikipedia.org/wiki/Sceneggiatore\">sceneggiatore</a> statunitense <a title=\"David Chase\" href=\"http://it.wikipedia.org/wiki/David_Chase\">David Chase</a> che, oltre a tutti i soggetti, firma anche la <a title=\"Regia\" href=\"http://it.wikipedia.org/wiki/Regia\">regia</a> del <a title=\"Episodi de I Soprano (prima stagione)\" href=\"http://it.wikipedia.org/wiki/Episodi_de_I_Soprano_%28prima_stagione%29#Affari_di_famiglia\">primo</a> e dell\'<a title=\"Episodi de I Soprano (sesta stagione)\" href=\"http://it.wikipedia.org/wiki/Episodi_de_I_Soprano_%28sesta_stagione%29#Made_in_America\">ultimo</a> episodio.</p>
<p>Il serial tv descrive la vita di <a title=\"Tony Soprano\" href=\"http://it.wikipedia.org/wiki/Tony_Soprano\">Tony Soprano</a>, <a class=\"mw-redirect\" title=\"Boss (mafia)\" href=\"http://it.wikipedia.org/wiki/Boss_%28mafia%29\">boss</a> della <a title=\"Mafia\" href=\"http://it.wikipedia.org/wiki/Mafia\">mafia</a> italoamericana: la famiglia Soprano, i cui avi italiani sono originari di <a title=\"Avellino\" href=\"http://it.wikipedia.org/wiki/Avellino\">Avellino</a>, vive nel <a title=\"New Jersey\" href=\"http://it.wikipedia.org/wiki/New_Jersey\">New Jersey</a>, vanta importanti contatti con le cosche newyorchesi e mantiene relazioni affaristiche con la <a title=\"Camorra\" href=\"http://it.wikipedia.org/wiki/Camorra\">camorra</a> napoletana.</p>','txt');
INSERT INTO contents (`id`,`abstract`,`body`,`type`) VALUES ('4','','<p><em><strong>Battlestar Galactica</strong></em> &egrave; una <a title=\"Serie televisiva\" href=\"http://it.wikipedia.org/wiki/Serie_televisiva\">serie televisiva</a> <a title=\"Canada\" href=\"http://it.wikipedia.org/wiki/Canada\">canadese</a> di <a title=\"Fantascienza\" href=\"http://it.wikipedia.org/wiki/Fantascienza\">fantascienza</a> trasmessa per la prima volta nell\'anno <a title=\"2003\" href=\"http://it.wikipedia.org/wiki/2003\">2003</a> dal network <a title=\"Sci Fi Channel\" href=\"http://it.wikipedia.org/wiki/Sci_Fi_Channel\">Sci Fi Channel</a> che ne cura anche la produzione. &Egrave; il <em><a title=\"Remake\" href=\"http://it.wikipedia.org/wiki/Remake\">remake</a></em> della serie televisiva <em><a title=\"Galactica\" href=\"http://it.wikipedia.org/wiki/Galactica\">Galactica</a></em> del <a title=\"1978\" href=\"http://it.wikipedia.org/wiki/1978\">1978</a> prodotta dalla <a title=\"American Broadcasting Company\" href=\"http://it.wikipedia.org/wiki/American_Broadcasting_Company\">ABC</a> ed interrotta dopo una sola stagione a causa degli elevati costi di produzione.</p>
<p>Nei 25 anni trascorsi dall\'improvvisa conclusione della serie originale fino alla messa in onda del recente prodotto televisivo si erano alternati vari tentativi per mantenere o riportare in vita le storie e i personaggi originali, senza per&ograve; ottenere alcun successo, oppure trasmettendo pochi episodi sparuti, rivelatisi poi dei veri e propri fiaschi.</p>
<p>Nel <a title=\"2002\" href=\"http://it.wikipedia.org/wiki/2002\">2002</a> SciFi annunci&ograve; per&ograve; la volont&agrave; di produrre un <em><a title=\"Pilot\" href=\"http://it.wikipedia.org/wiki/Pilot\">pilot</a></em> in due puntate di una eventuale serie <em>remake</em>, ridisegnando in parte l\'ambiente, la storia e i personaggi della serie originale; allo scopo di ottenere un risultato soddisfacente, si affida all\'inventiva di <a class=\"new\" title=\"Ronald D. Moore (pagina inesistente)\" href=\"http://it.wikipedia.org/w/index.php?title=Ronald_D._Moore&amp;action=edit&amp;redlink=1\">Ronald D. Moore</a>, gi&agrave; veterano di <em><a title=\"Star Trek\" href=\"http://it.wikipedia.org/wiki/Star_Trek\">Star Trek</a></em>. Il consenso del pubblico americano ed i riconoscimenti accademici della <em><a class=\"new\" title=\"Visual Effects Society (pagina inesistente)\" href=\"http://it.wikipedia.org/w/index.php?title=Visual_Effects_Society&amp;action=edit&amp;redlink=1\">Visual Effects Society</a></em>, che nel <a title=\"2004\" href=\"http://it.wikipedia.org/wiki/2004\">2004</a> assegna a <em>Battlestar Galactica</em> un <em>VES Award</em> per gli <a title=\"Effetti speciali\" href=\"http://it.wikipedia.org/wiki/Effetti_speciali\">effetti speciali visivi</a> in aggiunta a due <em><a title=\"Nomination\" href=\"http://it.wikipedia.org/wiki/Nomination\">nomination</a></em> per il compositing e la realizzazione di modelli e miniature, hanno poi convinto la SciFi della bont&agrave; del prodotto e hanno rafforzato la convinzione di produrre una serie televisiva completa.</p>','txt');
INSERT INTO contents (`id`,`type`) VALUES ('5','txt');
INSERT INTO contents (`id`,`type`) VALUES ('6','txt');
INSERT INTO contents (`id`,`type`) VALUES ('7','txt');
INSERT INTO contents (`id`,`abstract`,`body`,`type`) VALUES ('10','','<p>Prodotta dalla <a class=\"new\" title=\"Warner Bros. Television (pagina inesistente)\" href=\"http://it.wikipedia.org/w/index.php?title=Warner_Bros._Television&amp;action=edit&amp;redlink=1\">Warner Bros. Television</a> e dalla Chuck Lorre Productions, la serie &egrave; stata prolungata per un totale di 17 episodi e va in onda ogni luned&igrave; sul canale americano CBS.</p>
<p>La serie racconta le disavventure di due giovani fisici che vivono accanto a una bellissima ragazza, dalla dubbia intelligenza. Quando uno dei due si innamora della ragazza, l\'altro cerca di scoraggiarlo, ben sapendo che difficilmente potr&agrave; accettare il suo complicato mondo di stranezze.</p>
<p>In Italia, i primi quattro episodi della serie sono stati trasmessi su <a title=\"Steel\" href=\"http://it.wikipedia.org/wiki/Steel\">Steel</a>, canale a pagamento del digitale terrestre Premium Gallery, a partire dal <a title=\"19 gennaio\" href=\"http://it.wikipedia.org/wiki/19_gennaio\">19 gennaio</a> <a title=\"2008\" href=\"http://it.wikipedia.org/wiki/2008\">2008</a>. I restanti episodi, sono andati in onda sempre su Steel a partire dal <a title=\"22 agosto\" href=\"http://it.wikipedia.org/wiki/22_agosto\">22 agosto</a> <a title=\"2008\" href=\"http://it.wikipedia.org/wiki/2008\">2008</a>.</p>','txt');
INSERT INTO contents (`id`,`abstract`,`body`) VALUES ('13','','<p>The show was noted for its surreality, <a class=\"extiw\" title=\"wiktionary:risqu&eacute;\" href=\"http://en.wiktionary.org/wiki/risqu%C3%A9\">risqu&eacute;</a> or <a title=\"Innuendo\" href=\"http://en.wikipedia.org/wiki/Innuendo\">innuendo</a>-laden humour, sight gags, and sketches without punchlines. It also featured the iconic animations of <a title=\"Terry Gilliam\" href=\"http://en.wikipedia.org/wiki/Terry_Gilliam\">Terry Gilliam</a>, which were often sequenced or merged with live action.</p>
<p>The first episode was recorded on 7 September and broadcast on 5 October 1969 on <a title=\"BBC One\" href=\"http://en.wikipedia.org/wiki/BBC_One\">BBC One</a>, with 45 episodes airing over four seasons, plus 2 episodes for German TV.</p>
<p>The show often targeted the idiosyncrasies of British life (especially professionals) and was at times politically charged. The members of Monty Python were highly educated (<a title=\"Terry Jones\" href=\"http://en.wikipedia.org/wiki/Terry_Jones\">Terry Jones</a> and <a title=\"Michael Palin\" href=\"http://en.wikipedia.org/wiki/Michael_Palin\">Michael Palin</a> are <a title=\"University of Oxford\" href=\"http://en.wikipedia.org/wiki/University_of_Oxford\">Oxford</a> graduates; while <a title=\"Eric Idle\" href=\"http://en.wikipedia.org/wiki/Eric_Idle\">Eric Idle</a>, <a title=\"John Cleese\" href=\"http://en.wikipedia.org/wiki/John_Cleese\">John Cleese</a> and <a title=\"Graham Chapman\" href=\"http://en.wikipedia.org/wiki/Graham_Chapman\">Graham Chapman</a> are <a title=\"University of Cambridge\" href=\"http://en.wikipedia.org/wiki/University_of_Cambridge\">Cambridge</a> graduates; and <a title=\"United States\" href=\"http://en.wikipedia.org/wiki/United_States\">American</a>-born member <a title=\"Terry Gilliam\" href=\"http://en.wikipedia.org/wiki/Terry_Gilliam\">Terry Gilliam</a> is an <a title=\"Occidental College\" href=\"http://en.wikipedia.org/wiki/Occidental_College\">Occidental College</a> graduate), with their comedy often pointedly <a title=\"Intellectual\" href=\"http://en.wikipedia.org/wiki/Intellectual\">intellectual</a> by way of numerous references to <a class=\"mw-redirect\" title=\"Philosopher\" href=\"http://en.wikipedia.org/wiki/Philosopher\">philosophers</a> and <a title=\"Literature\" href=\"http://en.wikipedia.org/wiki/Literature\">literary</a> figures. It followed and elaborated upon the style used by <a title=\"Spike Milligan\" href=\"http://en.wikipedia.org/wiki/Spike_Milligan\">Spike Milligan</a> in his series <em><a title=\"Q (TV series)\" href=\"http://en.wikipedia.org/wiki/Q_%28TV_series%29\">Q5</a>,</em> rather than the traditional sketch show format. The team intended their humour to be impossible to categorise, and succeeded so completely that the adjective \"Pythonesque\" had to be invented to define it, and later, similar material. Despite this, Jones once commented that the fact that they had created a new word in the dictionary shows how miserably they had failed.</p>
<p>The Pythons played the majority of the series characters themselves, including the majority of the female characters, but occasionally they required an extra actor. Regular supporting cast members included <a title=\"Carol Cleveland\" href=\"http://en.wikipedia.org/wiki/Carol_Cleveland\">Carol Cleveland</a> (referred to by the team as the unofficial \"Seventh Python\"), <a title=\"Connie Booth\" href=\"http://en.wikipedia.org/wiki/Connie_Booth\">Connie Booth</a> (Cleese\'s then-Wife), Series Director <a title=\"Ian MacNaughton\" href=\"http://en.wikipedia.org/wiki/Ian_MacNaughton\">Ian MacNaughton</a>, <a title=\"Neil Innes\" href=\"http://en.wikipedia.org/wiki/Neil_Innes\">Neil Innes</a> (in the fourth series) and The <a class=\"new\" title=\"Fred Tomlinson Singers (page does not exist)\" href=\"http://en.wikipedia.org/w/index.php?title=Fred_Tomlinson_Singers&amp;action=edit&amp;redlink=1\">Fred Tomlinson Singers</a> (for musical numbers).</p>');
INSERT INTO contents (`id`) VALUES ('14');
INSERT INTO contents (`id`) VALUES ('15');
INSERT INTO contents (`id`) VALUES ('18');
INSERT INTO contents (`id`,`abstract`,`body`) VALUES ('19','','<p>Its title is an amalgamation of the terms \'<a title=\"Little Englander\" href=\"http://en.wikipedia.org/wiki/Little_Englander\">Little England</a>\' and \'Great Britain\', and is also the name of a <a title=\"Victorian architecture\" href=\"http://en.wikipedia.org/wiki/Victorian_architecture\">Victorian</a> neighbourhood and modern street in London.<sup id=\"cite_ref-0\" class=\"reference\"><a href=\"http://en.wikipedia.org/wiki/Little_Britain#cite_note-0\"><span>[</span>1<span>]</span></a></sup></p>
<p>The show comprises sketches involving exaggerated parodies of British people from all walks of life in various situations familiar to the British. These sketches are presented to the viewer together with narration in a manner which suggests that the programme is a guide &mdash; aimed at non-British people &mdash; to the ways of life of various classes of British society. Despite the narrator\'s description of great British institutions, the comedy is derived from the British audience\'s self-deprecating understanding of either themselves or people known to them.</p>
<p>An American version of the show, entitled <em><a title=\"Little Britain USA\" href=\"http://en.wikipedia.org/wiki/Little_Britain_USA\">Little Britain USA</a></em> was created in 2008. This series is shown on <a title=\"HBO\" href=\"http://en.wikipedia.org/wiki/HBO\">HBO</a> in the USA, &amp; also shown in Canada. It is shown on the <a title=\"BBC\" href=\"http://en.wikipedia.org/wiki/BBC\">BBC</a> in the UK.</p>
<p>Many of the characters on the show have their own often-repeated catchphrases. Many have become well-known in the United Kingdom, and the show has gained a mainstream following.</p>');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('1','bedita','2008-12-03 17:53:12','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('2','bedita','2008-12-03 18:00:21','area Television programssaved','info','areas');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('3','bedita','2008-12-03 18:04:04','section [serial dramas] saved','info','areas');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('4','bedita','2008-12-03 18:08:56','document [I Soprano] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('5','bedita','2008-12-03 18:12:21','document [Battlestar Galactica] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('6','bedita','2008-12-03 18:14:16','document [Battlestar Galactica] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('7','bedita','2008-12-03 18:18:49','multimedia object [number six] saved','info','multimedia');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('8','bedita','2008-12-03 18:20:48','document [Battlestar Galactica] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('9','bedita','2008-12-03 18:26:20','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('10','bedita','2008-12-03 18:29:06','multimedia object [Stagione finale sopranos] saved','info','multimedia');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('11','bedita','2008-12-03 18:29:24','multimedia object [Stagione finale sopranos] saved','info','multimedia');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('12','bedita','2008-12-15 12:48:33','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('13','bedita','2009-02-25 18:32:53','login not authorized','warn','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('14','-','2009-02-25 18:32:53','logged out','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('15','bedita','2009-02-25 18:33:35','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('16','bedita','2009-02-25 18:35:55','document [Battlestar Galactica] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('17','bedita','2009-02-25 18:36:36','logged out','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('18','bedita','2009-02-25 18:36:45','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('19','bedita','2009-02-25 18:37:08','logged out','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('20','bedita','2009-03-03 12:23:35','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('21','bedita','2009-03-03 12:25:12','multimedia object [BSG season 4 Promo] saved','info','multimedia');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('22','bedita','2009-03-03 12:26:22','document [Battlestar Galactica] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('23','bedita','2009-03-03 12:54:38','webmark [BSG Official Website] saved','info','webmarks');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('24','bedita','2009-03-03 13:00:14','document [Battlestar Galactica] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('25','bedita','2009-03-25 12:47:53','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('26','bedita','2009-03-25 12:49:58','Error loading document: 8','err','questionnaires');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('27','bedita','2009-03-25 12:49:58','Error loading document: 8','err','questionnaires');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('28','bedita','2009-03-25 12:56:13','section [situation comedies] saved','info','areas');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('29','bedita','2009-03-25 12:57:55','document [Big Bang Theory] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('30','bedita','2009-03-25 13:02:31','document [Big Bang Theory] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('31','bedita','2009-07-24 12:55:19','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('32','bedita','2009-07-24 13:32:02','section [sketch comedies] saved','info','areas');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('33','bedita','2009-07-24 13:32:39','section [sketch comedies] saved','info','areas');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('34','bedita','2009-07-24 17:19:23','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('35','bedita','2009-07-24 17:19:42','user beditatest updated','info','admin');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('36','bedita','2009-07-24 17:19:43','Module [admin] access not authorized','err','admin');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('37','bedita','2009-07-24 17:19:52','logged out','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('38','bedita','2009-07-24 17:19:59','login not authorized','warn','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('39','-','2009-07-24 17:19:59','logged out','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('40','beditatest','2009-07-24 17:20:10','logged in','info','authentications');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('41','beditatest','2009-07-24 17:24:31','document [Monty Python\'s Flying Circus] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('42','beditatest','2009-07-24 17:24:45','document [Monty Python\'s Flying Circus] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('43','beditatest','2009-07-24 17:26:24','document [Monty Python\'s Flying Circus] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('44','beditatest','2009-07-24 17:26:45','multimedia object [pythons] saved','info','multimedia');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('45','beditatest','2009-07-24 17:45:51','document [Monty Python\'s Flying Circus] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('46','beditatest','2009-07-24 17:50:15','document [Monty Python\'s Flying Circus] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('47','beditatest','2009-07-24 18:01:36','document [Little Britain] saved','info','documents');
INSERT INTO event_logs (`id`,`user`,`created`,`msg`,`level`,`context`) VALUES ('48','beditatest','2009-07-24 18:01:49','document [Little Britain] saved','info','documents');
INSERT INTO geo_tags (`id`,`object_id`,`address`,`gmaps_lookat`) VALUES ('1','3','','');
INSERT INTO geo_tags (`id`,`object_id`,`address`) VALUES ('3','4','');
INSERT INTO geo_tags (`id`,`object_id`,`address`) VALUES ('5','10','');
INSERT INTO geo_tags (`id`,`object_id`,`address`) VALUES ('10','13','');
INSERT INTO geo_tags (`id`,`object_id`,`address`) VALUES ('12','19','');
INSERT INTO groups (`id`,`name`,`backend_auth`,`immutable`) VALUES ('1','administrator','1','1');
INSERT INTO groups (`id`,`name`,`backend_auth`,`immutable`) VALUES ('2','guest','1','0');
INSERT INTO groups (`id`,`name`,`backend_auth`,`immutable`) VALUES ('3','editor','1','0');
INSERT INTO groups (`id`,`name`,`backend_auth`,`immutable`) VALUES ('4','reader','1','0');
INSERT INTO groups (`id`,`name`,`backend_auth`,`immutable`) VALUES ('5','frontend','0','0');
INSERT INTO groups (`id`,`name`,`backend_auth`,`immutable`) VALUES ('6','translator','1','1');
INSERT INTO groups_users (`user_id`,`group_id`) VALUES ('1','1');
INSERT INTO images (`id`,`width`,`height`) VALUES ('5','300','400');
INSERT INTO images (`id`,`width`,`height`) VALUES ('6','760','664');
INSERT INTO images (`id`,`width`,`height`) VALUES ('14','120','86');
INSERT INTO images (`id`,`width`,`height`) VALUES ('15','500','321');
INSERT INTO images (`id`,`width`,`height`) VALUES ('18','850','1280');
INSERT INTO links (`id`,`url`,`http_code`,`http_response_date`) VALUES ('8','http://www.scifi.com/battlestar/','HTTP/1.0 200 OK','2009-03-03 12:54:38');
INSERT INTO mail_jobs (`id`,`status`,`created`,`modified`,`mail_body`,`recipient`,`mail_params`) VALUES ('1','unsent','2009-07-24 17:19:42','2009-07-24 17:19:42','Hi beditatest, 
your account has been changed on BEdita at 
http://localhost/wp/bedita/index.php

Account data
----------

Real Name: BEdita
Userid: beditatest
Your password was changed!
',' ','a:4:{s:8:\"reply_to\";s:18:\"noreply@bedita.com\";s:6:\"sender\";s:18:\"noreply@bedita.com\";s:7:\"subject\";s:24:\"[BEdita] account changed\";s:9:\"signature\";s:41:\"powered by BEdita - http://www.bedita.com\";}');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('1','areas','publishing','areas','on','1');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('2','admin','admin','admin','on','15');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('3','translations','translations','translations','on','8');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('6','documents','documents','documents','on','2');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('7','news','news','news','on','9');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('8','galleries','galleries','galleries','on','5');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('10','events','events','events','on','3');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('11','bibliographies','bibliographies','bibliographies','on','14');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('12','webmarks','webmarks','webmarks','on','12');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('13','books','books','books','on','13');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('14','questionnaires','questionnaires','questionnaires','on','15');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('16','addressbook','addressbook','addressbook','on','10');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('18','newsletter','newsletter','newsletter','on','11');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('23','statistics','statistics','statistics','on','16');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('24','tags','tags','tags','on','6');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('25','comments','comments','comments','on','7');
INSERT INTO modules (`id`,`name`,`label`,`path`,`status`,`priority`) VALUES ('26','multimedia','multimedia','multimedia','on','4');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('4','2');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('5','1');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('6','1');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('7','3');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('13','4');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('13','5');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('13','6');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('14','1');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('15','1');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('18','1');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('19','4');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('19','5');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('19','6');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('19','7');
INSERT INTO object_categories (`object_id`,`category_id`) VALUES ('19','8');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('4','5','attach','2');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('4','7','attach','2');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('4','8','link','1');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('5','4','attach','2');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('7','4','attach','1');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('8','4','link','1');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('13','14','attach','3');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('13','15','attach','3');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('14','13','attach','1');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('15','13','attach','2');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('18','19','attach','1');
INSERT INTO object_relations (`object_id`,`id`,`switch`,`priority`) VALUES ('19','18','attach','2');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('1','area','areas');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('3','section','areas');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('10','befile','multimedia');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('12','image','multimedia');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('13','comment','comments');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('18','shortnews','news');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('19','bibliography','bibliographies');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('20','book','books');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('21','event','events');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('22','document','documents');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('29','gallery','galleries');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('30','application','multimedia');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('31','audio','multimedia');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('32','video','multimedia');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('33','link','webmarks');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('34','card','addressbook');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('35','mailmessage','newsletter');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('36','mailtemplate','newsletter');
INSERT INTO object_types (`id`,`name`) VALUES ('37','author');
INSERT INTO object_types (`id`,`name`) VALUES ('38','biblioitem');
INSERT INTO object_types (`id`,`name`) VALUES ('39','editornote');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('40','question','questionnaires');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('41','questionnaire','questionnaires');
INSERT INTO object_types (`id`,`name`,`module`) VALUES ('42','questionnaireresult','questionnaires');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`fixed`,`comments`) VALUES ('1','1','on','2008-12-03 18:00:20','2008-12-03 18:00:20','Television programs','television-programs','un chiaro esempio del vero motivo per cui abbiamo fatto bedita','1','ita','127.0.0.1','1','1','riservati','','Ste','Lo stiamo cercando','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`fixed`,`comments`) VALUES ('2','3','on','2008-12-03 18:04:04','2008-12-03 18:04:04','serial dramas','serial-dramas','le nostre serie preferite','1','ita','127.0.0.1','1','1','','Creative Commons Attribuzione-Non commerciale-Condividi allo stesso modo 2.5 Italia','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`note`,`fixed`,`comments`) VALUES ('3','22','on','2008-12-03 18:08:55','2008-12-03 18:08:55','I Soprano','i-soprano','I Soprano è una serie televisiva prodotta dall\'emittente americana HBO','1','ita','127.0.0.1','1','1','','','Tony Soprano','','','0','on');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`note`,`fixed`,`comments`) VALUES ('4','22','draft','2008-12-03 18:12:20','2009-03-03 13:00:12','Battlestar Galactica','battlestar-galactica','Serie televisiva canadese di fantascienza trasmessa per la prima volta nell\'anno 2003 dal network Sci Fi Channel che ne cura anche la produzione. È il remake della serie televisiva Galactica del 1978 prodotta dalla ABC ed interrotta dopo una sola stagione a causa degli elevati costi di produzione.','1','ita','::1','1','1','','','','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`note`,`fixed`,`comments`) VALUES ('5','12','draft','2008-12-03 18:18:48','2008-12-03 18:18:48','number six','number-six','molto brava','1','ita','127.0.0.1','1','1','','','','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`note`,`fixed`,`comments`) VALUES ('6','12','on','2008-12-03 18:29:05','2008-12-03 18:29:24','Stagione finale sopranos','stagione-finale-sopranos','sopranos, serie 6','1','ita','127.0.0.1','1','1','','','','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`note`,`fixed`,`comments`) VALUES ('7','32','on','2009-02-25 18:35:24','2009-03-03 12:25:12','BSG season 4 Promo','youtube-video','Promo della quarta e ultima stagione di Battlestar','1','ita','::1','1','1','','','','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`note`,`fixed`,`comments`) VALUES ('8','33','draft','2009-03-03 12:54:38','2009-03-03 12:54:38','BSG Official Website','bsg-official-website','','1','ita','::1','1','1','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`fixed`,`comments`) VALUES ('9','3','on','2009-03-25 12:56:13','2009-03-25 12:56:13','situation comedies','situation-comedies','Situation comedies','1','ita','::1','1','1','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`note`,`fixed`,`comments`) VALUES ('10','22','on','2009-03-25 12:57:55','2009-03-25 13:02:31','Big Bang Theory','big-bang-theory','The Big Bang Theory è una situation comedy americana creata e prodotta da Chuck Lorre e Bill Prady','1','ita','::1','1','1','','','sheldon','','a note','0','on');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`fixed`,`comments`) VALUES ('11','13','on','2009-03-25 13:00:44','2009-03-25 13:01:01','engineering','engineering','Engineering: where the noble semi-skilled laborers execute the vision of those who think and dream. Hello, Ooompa-Loompas of science.','1','ita','127.0.0.1','1','1','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`fixed`,`comments`) VALUES ('12','3','on','2009-07-24 13:32:02','2009-07-24 13:32:39','sketch comedies','sketch-comedies','Sketch comedies section','1','eng','::1','1','1','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`fixed`,`comments`) VALUES ('13','22','on','2009-07-24 17:24:30','2009-07-24 17:50:15','Monty Python\'s Flying Circus','monty-python-s-flying-circus','A BBC sketch comedy programme from the Monty Python comedy team, and the group\'s initial claim to fame.','1','eng','::1','1','1','','','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`fixed`,`comments`) VALUES ('14','12','on','2009-07-24 17:26:00','2009-07-24 17:26:45','pythons','pythos','','1','eng','::1','1','1','','','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`fixed`,`comments`) VALUES ('15','12','on','2009-07-24 17:26:19','2009-07-24 17:26:19','pythons again!','pythons-again','','1','eng','::1','1','1','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`fixed`,`comments`) VALUES ('16','39','draft','2009-07-24 17:44:08','2009-07-24 17:44:08','editornote-0','Oh, wicked. Wicked. You\'re wicked. Eh? 
Know what I mean? Nudge nudge. Know what I mean? Nudge nudge. Nudge nudge. Say no more... say no more','1','eng','::1','1','1','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`fixed`,`comments`) VALUES ('17','39','draft','2009-07-24 17:45:10','2009-07-24 17:45:10','editornote-1','If only Bicycle Repair Man were here!','1','eng','::1','1','1','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`fixed`,`comments`) VALUES ('18','12','on','2009-07-24 18:01:03','2009-07-24 18:01:03','Andy & Lou','andy-lou','','1','eng','::1','1','1','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`rights`,`license`,`creator`,`publisher`,`fixed`,`comments`) VALUES ('19','22','on','2009-07-24 18:01:35','2009-07-24 18:01:48','Little Britain','little-britain','An award winning character-based comedy sketch show first appearing on BBC radio and then television. Written by Matt Lucas and David Walliams.','1','eng','::1','1','1','','','','','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`fixed`,`comments`) VALUES ('20','13','on','2009-07-24 18:04:01','2009-07-24 18:04:01','yeah I know','yeah-i-know','I want that one!','1','eng','127.0.0.1','1','1','0','off');
INSERT INTO objects (`id`,`object_type_id`,`status`,`created`,`modified`,`title`,`nickname`,`description`,`current`,`lang`,`ip_created`,`user_created`,`user_modified`,`fixed`,`comments`) VALUES ('21','13','on','2009-07-24 18:05:17','2009-07-24 18:05:17','Computer says no...','computer-says-no','Oh my God! I sooo can\'t believe you just said that!','1','eng','127.0.0.1','1','1','0','off');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('1','2','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('2','1','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('3','6','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('4','8','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('5','26','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('6','7','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('7','10','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('8','24','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('9','25','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('10','3','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('11','13','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('12','11','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('13','16','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('14','18','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('15','23','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('16','12','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('17','14','1','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('18','1','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('19','6','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('20','8','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('21','26','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('22','7','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('23','10','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('24','24','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('25','25','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('26','3','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('27','13','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('28','11','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('29','16','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('30','18','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('31','23','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('32','12','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('33','14','3','group','3');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('34','1','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('35','6','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('36','8','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('37','26','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('38','7','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('39','10','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('40','24','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('41','25','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('42','3','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('43','13','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('44','11','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('45','16','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('46','18','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('47','23','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('48','12','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('49','14','4','group','1');
INSERT INTO permission_modules (`id`,`module_id`,`ugid`,`switch`,`flag`) VALUES ('50','3','6','group','3');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('3','1','1','group','15');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('4','1','2','group','1');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('7','2','1','group','15');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('8','2','2','group','1');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('11','3','1','group','15');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('12','3','2','group','1');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('15','4','1','group','255');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('16','4','2','group','1');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('19','5','1','group','15');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('20','5','2','group','1');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('25','6','1','group','15');
INSERT INTO permissions (`id`,`object_id`,`ugid`,`switch`,`flag`) VALUES ('26','6','2','group','1');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('1','1','ita','my tv movies','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('2','1','ita','Television programs','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('3','1','ita','un chiaro esempio del vero motivo per cui abbiamo fatto bedita','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('4','2','ita','serial dramas','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('5','2','ita','le nostre serie preferite','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('6','3','ita','<p><em><strong>I Soprano</strong></em> &egrave; una <a title=\"Serie televisiva\" href=\"http://it.wikipedia.org/wiki/Serie_televisiva\">serie televisiva</a> prodotta dall\'<a title=\"Emittente televisiva\" href=\"http://it.wikipedia.org/wiki/Emittente_televisiva\">emittente</a> americana <a class=\"mw-redirect\" title=\"HBO\" href=\"http://it.wikipedia.org/wiki/HBO\">HBO</a> e trasmessa in <a title=\"Italia\" href=\"http://it.wikipedia.org/wiki/Italia\">Italia</a> per la prima volta dalla rete televisiva <a title=\"Canale 5\" href=\"http://it.wikipedia.org/wiki/Canale_5\">Canale 5</a>. Ideatore e produttore della serie &egrave; lo <a class=\"mw-redirect\" title=\"Sceneggiatore\" href=\"http://it.wikipedia.org/wiki/Sceneggiatore\">sceneggiatore</a> statunitense <a title=\"David Chase\" href=\"http://it.wikipedia.org/wiki/David_Chase\">David Chase</a> che, oltre a tutti i soggetti, firma anche la <a title=\"Regia\" href=\"http://it.wikipedia.org/wiki/Regia\">regia</a> del <a title=\"Episodi de I Soprano (prima stagione)\" href=\"http://it.wikipedia.org/wiki/Episodi_de_I_Soprano_%28prima_stagione%29#Affari_di_famiglia\">primo</a> e dell\'<a title=\"Episodi de I Soprano (sesta stagione)\" href=\"http://it.wikipedia.org/wiki/Episodi_de_I_Soprano_%28sesta_stagione%29#Made_in_America\">ultimo</a> episodio.</p>
<p>Il serial tv descrive la vita di <a title=\"Tony Soprano\" href=\"http://it.wikipedia.org/wiki/Tony_Soprano\">Tony Soprano</a>, <a class=\"mw-redirect\" title=\"Boss (mafia)\" href=\"http://it.wikipedia.org/wiki/Boss_%28mafia%29\">boss</a> della <a title=\"Mafia\" href=\"http://it.wikipedia.org/wiki/Mafia\">mafia</a> italoamericana: la famiglia Soprano, i cui avi italiani sono originari di <a title=\"Avellino\" href=\"http://it.wikipedia.org/wiki/Avellino\">Avellino</a>, vive nel <a title=\"New Jersey\" href=\"http://it.wikipedia.org/wiki/New_Jersey\">New Jersey</a>, vanta importanti contatti con le cosche newyorchesi e mantiene relazioni affaristiche con la <a title=\"Camorra\" href=\"http://it.wikipedia.org/wiki/Camorra\">camorra</a> napoletana.</p>','4');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('7','3','ita','I Soprano','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('8','3','ita','I Soprano è una serie televisiva prodotta dall\'emittente americana HBO','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('48','4','ita','Serie televisiva canadese di fantascienza trasmessa per la prima volta nell\'anno 2003 dal network Sci Fi Channel che ne cura anche la produzione. È il remake della serie televisiva Galactica del 1978 prodotta dalla ABC ed interrotta dopo una sola stagione a causa degli elevati costi di produzione.','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('46','4','ita','<p><em><strong>Battlestar Galactica</strong></em> &egrave; una <a title=\"Serie televisiva\" href=\"http://it.wikipedia.org/wiki/Serie_televisiva\">serie televisiva</a> <a title=\"Canada\" href=\"http://it.wikipedia.org/wiki/Canada\">canadese</a> di <a title=\"Fantascienza\" href=\"http://it.wikipedia.org/wiki/Fantascienza\">fantascienza</a> trasmessa per la prima volta nell\'anno <a title=\"2003\" href=\"http://it.wikipedia.org/wiki/2003\">2003</a> dal network <a title=\"Sci Fi Channel\" href=\"http://it.wikipedia.org/wiki/Sci_Fi_Channel\">Sci Fi Channel</a> che ne cura anche la produzione. &Egrave; il <em><a title=\"Remake\" href=\"http://it.wikipedia.org/wiki/Remake\">remake</a></em> della serie televisiva <em><a title=\"Galactica\" href=\"http://it.wikipedia.org/wiki/Galactica\">Galactica</a></em> del <a title=\"1978\" href=\"http://it.wikipedia.org/wiki/1978\">1978</a> prodotta dalla <a title=\"American Broadcasting Company\" href=\"http://it.wikipedia.org/wiki/American_Broadcasting_Company\">ABC</a> ed interrotta dopo una sola stagione a causa degli elevati costi di produzione.</p>
<p>Nei 25 anni trascorsi dall\'improvvisa conclusione della serie originale fino alla messa in onda del recente prodotto televisivo si erano alternati vari tentativi per mantenere o riportare in vita le storie e i personaggi originali, senza per&ograve; ottenere alcun successo, oppure trasmettendo pochi episodi sparuti, rivelatisi poi dei veri e propri fiaschi.</p>
<p>Nel <a title=\"2002\" href=\"http://it.wikipedia.org/wiki/2002\">2002</a> SciFi annunci&ograve; per&ograve; la volont&agrave; di produrre un <em><a title=\"Pilot\" href=\"http://it.wikipedia.org/wiki/Pilot\">pilot</a></em> in due puntate di una eventuale serie <em>remake</em>, ridisegnando in parte l\'ambiente, la storia e i personaggi della serie originale; allo scopo di ottenere un risultato soddisfacente, si affida all\'inventiva di <a class=\"new\" title=\"Ronald D. Moore (pagina inesistente)\" href=\"http://it.wikipedia.org/w/index.php?title=Ronald_D._Moore&amp;action=edit&amp;redlink=1\">Ronald D. Moore</a>, gi&agrave; veterano di <em><a title=\"Star Trek\" href=\"http://it.wikipedia.org/wiki/Star_Trek\">Star Trek</a></em>. Il consenso del pubblico americano ed i riconoscimenti accademici della <em><a class=\"new\" title=\"Visual Effects Society (pagina inesistente)\" href=\"http://it.wikipedia.org/w/index.php?title=Visual_Effects_Society&amp;action=edit&amp;redlink=1\">Visual Effects Society</a></em>, che nel <a title=\"2004\" href=\"http://it.wikipedia.org/wiki/2004\">2004</a> assegna a <em>Battlestar Galactica</em> un <em>VES Award</em> per gli <a title=\"Effetti speciali\" href=\"http://it.wikipedia.org/wiki/Effetti_speciali\">effetti speciali visivi</a> in aggiunta a due <em><a title=\"Nomination\" href=\"http://it.wikipedia.org/wiki/Nomination\">nomination</a></em> per il compositing e la realizzazione di modelli e miniature, hanno poi convinto la SciFi della bont&agrave; del prodotto e hanno rafforzato la convinzione di produrre una serie televisiva completa.</p>','4');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('15','5','ita','number six','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('16','5','ita','molto brava','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('17','5','ita','battlestar-galactica-number6.jpg','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('29','6','ita','sopranos_seas6_poster.jpg','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('28','6','ita','sopranos, serie 6','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('27','6','ita','Stagione finale sopranos','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('42','7','ita','youtube video','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('41','7','ita','Promo della quarta e ultima stagione di Battlestar','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('40','7','ita','BSG season 4 Promo','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('47','4','ita','Battlestar Galactica','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('49','9','ita','situation comedies','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('50','9','ita','Situation comedies','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('58','10','ita','Big Bang Theory','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('59','10','ita','The Big Bang Theory è una situation comedy americana creata e prodotta da Chuck Lorre e Bill Prady','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('57','10','ita','<p>Prodotta dalla <a class=\"new\" title=\"Warner Bros. Television (pagina inesistente)\" href=\"http://it.wikipedia.org/w/index.php?title=Warner_Bros._Television&amp;action=edit&amp;redlink=1\">Warner Bros. Television</a> e dalla Chuck Lorre Productions, la serie &egrave; stata prolungata per un totale di 17 episodi e va in onda ogni luned&igrave; sul canale americano CBS.</p>
<p>La serie racconta le disavventure di due giovani fisici che vivono accanto a una bellissima ragazza, dalla dubbia intelligenza. Quando uno dei due si innamora della ragazza, l\'altro cerca di scoraggiarlo, ben sapendo che difficilmente potr&agrave; accettare il suo complicato mondo di stranezze.</p>
<p>In Italia, i primi quattro episodi della serie sono stati trasmessi su <a title=\"Steel\" href=\"http://it.wikipedia.org/wiki/Steel\">Steel</a>, canale a pagamento del digitale terrestre Premium Gallery, a partire dal <a title=\"19 gennaio\" href=\"http://it.wikipedia.org/wiki/19_gennaio\">19 gennaio</a> <a title=\"2008\" href=\"http://it.wikipedia.org/wiki/2008\">2008</a>. I restanti episodi, sono andati in onda sempre su Steel a partire dal <a title=\"22 agosto\" href=\"http://it.wikipedia.org/wiki/22_agosto\">22 agosto</a> <a title=\"2008\" href=\"http://it.wikipedia.org/wiki/2008\">2008</a>.</p>','4');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('61','12','eng','sketch comedies','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('62','12','eng','Sketch comedies section','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('85','13','eng','<p>The show was noted for its surreality, <a class=\"extiw\" title=\"wiktionary:risqu&eacute;\" href=\"http://en.wiktionary.org/wiki/risqu%C3%A9\">risqu&eacute;</a> or <a title=\"Innuendo\" href=\"http://en.wikipedia.org/wiki/Innuendo\">innuendo</a>-laden humour, sight gags, and sketches without punchlines. It also featured the iconic animations of <a title=\"Terry Gilliam\" href=\"http://en.wikipedia.org/wiki/Terry_Gilliam\">Terry Gilliam</a>, which were often sequenced or merged with live action.</p>
<p>The first episode was recorded on 7 September and broadcast on 5 October 1969 on <a title=\"BBC One\" href=\"http://en.wikipedia.org/wiki/BBC_One\">BBC One</a>, with 45 episodes airing over four seasons, plus 2 episodes for German TV.</p>
<p>The show often targeted the idiosyncrasies of British life (especially professionals) and was at times politically charged. The members of Monty Python were highly educated (<a title=\"Terry Jones\" href=\"http://en.wikipedia.org/wiki/Terry_Jones\">Terry Jones</a> and <a title=\"Michael Palin\" href=\"http://en.wikipedia.org/wiki/Michael_Palin\">Michael Palin</a> are <a title=\"University of Oxford\" href=\"http://en.wikipedia.org/wiki/University_of_Oxford\">Oxford</a> graduates; while <a title=\"Eric Idle\" href=\"http://en.wikipedia.org/wiki/Eric_Idle\">Eric Idle</a>, <a title=\"John Cleese\" href=\"http://en.wikipedia.org/wiki/John_Cleese\">John Cleese</a> and <a title=\"Graham Chapman\" href=\"http://en.wikipedia.org/wiki/Graham_Chapman\">Graham Chapman</a> are <a title=\"University of Cambridge\" href=\"http://en.wikipedia.org/wiki/University_of_Cambridge\">Cambridge</a> graduates; and <a title=\"United States\" href=\"http://en.wikipedia.org/wiki/United_States\">American</a>-born member <a title=\"Terry Gilliam\" href=\"http://en.wikipedia.org/wiki/Terry_Gilliam\">Terry Gilliam</a> is an <a title=\"Occidental College\" href=\"http://en.wikipedia.org/wiki/Occidental_College\">Occidental College</a> graduate), with their comedy often pointedly <a title=\"Intellectual\" href=\"http://en.wikipedia.org/wiki/Intellectual\">intellectual</a> by way of numerous references to <a class=\"mw-redirect\" title=\"Philosopher\" href=\"http://en.wikipedia.org/wiki/Philosopher\">philosophers</a> and <a title=\"Literature\" href=\"http://en.wikipedia.org/wiki/Literature\">literary</a> figures. It followed and elaborated upon the style used by <a title=\"Spike Milligan\" href=\"http://en.wikipedia.org/wiki/Spike_Milligan\">Spike Milligan</a> in his series <em><a title=\"Q (TV series)\" href=\"http://en.wikipedia.org/wiki/Q_%28TV_series%29\">Q5</a>,</em> rather than the traditional sketch show format. The team intended their humour to be impossible to categorise, and succeeded so completely that the adjective \"Pythonesque\" had to be invented to define it, and later, similar material. Despite this, Jones once commented that the fact that they had created a new word in the dictionary shows how miserably they had failed.</p>
<p>The Pythons played the majority of the series characters themselves, including the majority of the female characters, but occasionally they required an extra actor. Regular supporting cast members included <a title=\"Carol Cleveland\" href=\"http://en.wikipedia.org/wiki/Carol_Cleveland\">Carol Cleveland</a> (referred to by the team as the unofficial \"Seventh Python\"), <a title=\"Connie Booth\" href=\"http://en.wikipedia.org/wiki/Connie_Booth\">Connie Booth</a> (Cleese\'s then-Wife), Series Director <a title=\"Ian MacNaughton\" href=\"http://en.wikipedia.org/wiki/Ian_MacNaughton\">Ian MacNaughton</a>, <a title=\"Neil Innes\" href=\"http://en.wikipedia.org/wiki/Neil_Innes\">Neil Innes</a> (in the fourth series) and The <a class=\"new\" title=\"Fred Tomlinson Singers (page does not exist)\" href=\"http://en.wikipedia.org/w/index.php?title=Fred_Tomlinson_Singers&amp;action=edit&amp;redlink=1\">Fred Tomlinson Singers</a> (for musical numbers).</p>','4');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('87','13','eng','A BBC sketch comedy programme from the Monty Python comedy team, and the group\'s initial claim to fame.','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('86','13','eng','Monty Python\'s Flying Circus','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('78','14','eng','pythons','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('71','15','eng','pythons again!','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('72','15','eng','python.jpg','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('79','14','eng','monty.jpeg','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('80','16','eng','Oh, wicked. Wicked. You\'re wicked. Eh? 
Know what I mean? Nudge nudge. Know what I mean? Nudge nudge. Nudge nudge. Say no more... say no more','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('81','17','eng','If only Bicycle Repair Man were here!','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('88','18','eng','Andy & Lou','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('89','18','eng','AndyLou.jpg','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('94','19','eng','Little Britain','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('95','19','eng','An award winning character-based comedy sketch show first appearing on BBC radio and then television. Written by Matt Lucas and David Walliams.','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('93','19','eng','<p>Its title is an amalgamation of the terms \'<a title=\"Little Englander\" href=\"http://en.wikipedia.org/wiki/Little_Englander\">Little England</a>\' and \'Great Britain\', and is also the name of a <a title=\"Victorian architecture\" href=\"http://en.wikipedia.org/wiki/Victorian_architecture\">Victorian</a> neighbourhood and modern street in London.<sup id=\"cite_ref-0\" class=\"reference\"><a href=\"http://en.wikipedia.org/wiki/Little_Britain#cite_note-0\"><span>[</span>1<span>]</span></a></sup></p>
<p>The show comprises sketches involving exaggerated parodies of British people from all walks of life in various situations familiar to the British. These sketches are presented to the viewer together with narration in a manner which suggests that the programme is a guide &mdash; aimed at non-British people &mdash; to the ways of life of various classes of British society. Despite the narrator\'s description of great British institutions, the comedy is derived from the British audience\'s self-deprecating understanding of either themselves or people known to them.</p>
<p>An American version of the show, entitled <em><a title=\"Little Britain USA\" href=\"http://en.wikipedia.org/wiki/Little_Britain_USA\">Little Britain USA</a></em> was created in 2008. This series is shown on <a title=\"HBO\" href=\"http://en.wikipedia.org/wiki/HBO\">HBO</a> in the USA, &amp; also shown in Canada. It is shown on the <a title=\"BBC\" href=\"http://en.wikipedia.org/wiki/BBC\">BBC</a> in the UK.</p>
<p>Many of the characters on the show have their own often-repeated catchphrases. Many have become well-known in the United Kingdom, and the show has gained a mainstream following.</p>','4');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('96','20','eng','Andy','3');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('97','20','eng','yeah I know','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('98','20','eng','I want that one!','6');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('99','21','eng','Carol','3');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('100','21','eng','Computer says no...','10');
INSERT INTO search_texts (`id`,`object_id`,`lang`,`content`,`relevance`) VALUES ('101','21','eng','Oh my God! I sooo can\'t believe you just said that!','6');
INSERT INTO sections (`id`,`syndicate`,`priority_order`) VALUES ('1','off','asc');
INSERT INTO sections (`id`,`syndicate`,`priority_order`) VALUES ('2','off','asc');
INSERT INTO sections (`id`,`syndicate`,`priority_order`) VALUES ('9','off','asc');
INSERT INTO sections (`id`,`syndicate`,`priority_order`) VALUES ('12','off','asc');
INSERT INTO streams (`id`,`path`,`name`,`mime_type`,`size`,`hash_file`) VALUES ('5','/4c/a3/20/43/battlestar-galactica-number6.jpg','battlestar-galactica-number6.jpg','image/jpeg','58765','f051de746fa1929f0e3a9184fada53b7');
INSERT INTO streams (`id`,`path`,`name`,`mime_type`,`size`,`hash_file`) VALUES ('6','/3e/f0/db/1c/sopranos_seas6_poster.jpg','sopranos_seas6_poster.jpg','image/jpeg','149334','2d078f7d14687371387096cf2a4cbcec');
INSERT INTO streams (`id`,`path`,`name`,`mime_type`) VALUES ('7','http://www.youtube.com/watch?v=VysVxz2_rQg','youtube video','video/youtube');
INSERT INTO streams (`id`,`path`,`name`,`mime_type`,`size`,`hash_file`) VALUES ('14','/64/14/monty.jpeg','monty.jpeg','image/jpeg','2806','dec404d3878c70aaeb960d9401f6c0c8');
INSERT INTO streams (`id`,`path`,`name`,`mime_type`,`size`,`hash_file`) VALUES ('15','/7b/af/python.jpg','python.jpg','image/jpeg','159244','8818f8e9650d7ba712aa7449e87ef485');
INSERT INTO streams (`id`,`path`,`name`,`mime_type`,`size`,`hash_file`) VALUES ('18','/91/4d/AndyLou.jpg','AndyLou.jpg','image/jpeg','170777','e55a9125297d667148e4fbc6e9d54e1c');
INSERT INTO trees (`id`,`path`,`parent_path`,`priority`) VALUES ('1','/1','/','1');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('2','1','/1/2','/1','1');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('3','2','/1/2/3','/1/2','1');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('4','2','/1/2/4','/1/2','2');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('9','1','/1/9','/1','2');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('10','9','/1/9/10','/1/9','1');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('12','1','/1/12','/1','3');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('13','12','/1/12/13','/1/12','1');
INSERT INTO trees (`id`,`parent_id`,`path`,`parent_path`,`priority`) VALUES ('19','12','/1/12/19','/1/12','2');
INSERT INTO users (`id`,`userid`,`realname`,`passwd`,`email`,`valid`,`last_login`,`num_login_err`,`modified`,`level`) VALUES ('1','beditatest','BEdita','f69c518a361b5d77ee7d708d3c89cad7',' ','1','2009-07-24 17:20:10','0','2009-07-24 17:19:42','0');
INSERT INTO videos (`id`,`provider`,`uid`,`thumbnail`) VALUES ('7','youtube','VysVxz2_rQg','http://i.ytimg.com/vi/VysVxz2_rQg/default.jpg');
